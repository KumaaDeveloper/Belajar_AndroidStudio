package com.example.tugasintentbangun;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BangunRuangActivity extends AppCompatActivity {

    EditText edtPanjangBalok, edtLebarBalok, edtTinggiBalok;
    Button btnHitungBalok;
    TextView tvHasilBalok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bangun_ruang);

        edtPanjangBalok = findViewById(R.id.edtPanjangBalok);
        edtLebarBalok = findViewById(R.id.edtLebarBalok);
        edtTinggiBalok = findViewById(R.id.edtTinggiBalok);
        btnHitungBalok = findViewById(R.id.btnHitungBalok);
        tvHasilBalok = findViewById(R.id.tvHasilBalok);

        btnHitungBalok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String panjangStr = edtPanjangBalok.getText().toString();
                String lebarStr = edtLebarBalok.getText().toString();
                String tinggiStr = edtTinggiBalok.getText().toString();

                if (!panjangStr.isEmpty() && !lebarStr.isEmpty() && !tinggiStr.isEmpty()) {
                    double panjang = Double.parseDouble(panjangStr);
                    double lebar = Double.parseDouble(lebarStr);
                    double tinggi = Double.parseDouble(tinggiStr);
                    double volume = panjang * lebar * tinggi;
                    tvHasilBalok.setText("Volume Balok = " + volume);
                } else {
                    tvHasilBalok.setText("Input panjang, lebar, dan tinggi terlebih dahulu");
                }
            }
        });
    }
}