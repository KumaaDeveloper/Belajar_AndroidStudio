package com.example.tugasintentbangun;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnBangunDatar, btnBangunRuang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBangunDatar = findViewById(R.id.btnBangunDatar);
        btnBangunRuang = findViewById(R.id.btnBangunRuang);

        btnBangunDatar.setOnClickListener(this);
        btnBangunRuang.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnBangunDatar) {
            Intent intent = new Intent(MainActivity.this, BangunDatarActivity.class);
            startActivity(intent);
        } else if (v.getId() == R.id.btnBangunRuang) {
            Intent intent = new Intent(MainActivity.this, BangunRuangActivity.class);
            startActivity(intent);
        }
    }
}