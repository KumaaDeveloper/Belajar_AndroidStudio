package com.example.tugasintentbangun;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BangunDatarActivity extends AppCompatActivity {

    EditText edtPanjang, edtLebar, edtJariJari;
    Button btnHitungPersegiPanjang, btnHitungLingkaran;
    TextView tvHasilPersegiPanjang, tvHasilLingkaran;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bangun_datar);

        edtPanjang = findViewById(R.id.edtPanjang);
        edtLebar = findViewById(R.id.edtLebar);
        edtJariJari = findViewById(R.id.edtJariJari);

        btnHitungPersegiPanjang = findViewById(R.id.btnHitungPersegiPanjang);
        btnHitungLingkaran = findViewById(R.id.btnHitungLingkaran);

        tvHasilPersegiPanjang = findViewById(R.id.tvHasilPersegiPanjang);
        tvHasilLingkaran = findViewById(R.id.tvHasilLingkaran);

        btnHitungPersegiPanjang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String panjangStr = edtPanjang.getText().toString();
                String lebarStr = edtLebar.getText().toString();

                if (!panjangStr.isEmpty() && !lebarStr.isEmpty()) {
                    double panjang = Double.parseDouble(panjangStr);
                    double lebar = Double.parseDouble(lebarStr);
                    double luas = panjang * lebar;
                    tvHasilPersegiPanjang.setText("Luas Persegi Panjang = " + luas);
                } else {
                    tvHasilPersegiPanjang.setText("Input panjang dan lebar terlebih dahulu");
                }
            }
        });

        btnHitungLingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String rStr = edtJariJari.getText().toString();

                if (!rStr.isEmpty()) {
                    double r = Double.parseDouble(rStr);
                    double luas = 3.14 * r * r;
                    tvHasilLingkaran.setText("Luas Lingkaran = " + luas);
                } else {
                    tvHasilLingkaran.setText("Input jari-jari terlebih dahulu");
                }
            }
        });
    }
}